import React from "react";
import { Card, Typography } from "@material-tailwind/react";
import piano from "../images/piano.jpg";
import { AiFillPlayCircle } from "react-icons/ai";
import { BsFillMicMuteFill } from "react-icons/bs";
import { BiSolidMessageRounded } from "react-icons/bi";
import { BiDotsVerticalRounded } from "react-icons/bi";
import { MdCallEnd } from "react-icons/md";
import {BsDot} from "react-icons/bs"
import {BiSolidStopwatch} from "react-icons/bi"

const CourseCard = () => {
  return (
    <Card className="w-400">
      <div className="flex justify-between">
        <h3>Music Basics</h3>
        <div className="flex item-center rounded-full p-2 ">
          <div className="h-12 w-12 overflow-hidden rounded-full md:ml-4 cursor-pointer  mr-2 ">
            <img
              className="h-full w-full object-cover"
              src="https://xsgames.co/randomusers/assets/avatars/female/67.jpg"
              alt="user"
            />
          </div>
          <Typography className="text-black px-4  font-medium">
            John Mayer
          </Typography>
        </div>
      </div>

      <img src={piano} alt="piano" />
      <div className="flex justify-between space-x-4 py-4 relative">
        <AiFillPlayCircle />
        <BsFillMicMuteFill />
        <BiSolidMessageRounded />
        <BiDotsVerticalRounded />
        <MdCallEnd />

        <input
          
          className="px-3 py-2 pl-12 border rounded-3xl w-full focus:outline-none focus:border-blue-500 bg-slate-50"
        />
      </div>
      <div className="flex justify-between">
            <div className="flex flex-row">
            <BsDot/>
            <Typography>50 Lessons Available</Typography>
            </div>
            <div className="flex flex-row">
            <BiSolidStopwatch/>
            <Typography> Ends in: 45 min.</Typography>
            </div>
            

            
      </div>
    </Card>
  );
};

export default CourseCard;
